/* Halaqati v2.17.1 — category-aware reverse-surah smart plans runtime.
   Loaded after legacy so all integrations are additive wrappers. */
const smartPlansEngine=window.HalaqatiSmartPlansEngine;
const smartPlanTypeAr={hifz:'حفظ',review:'مراجعة',sard:'سرد',tathbit:'تثبيت'};
const smartPlanUnitAr={pages:'صفحات',juz:'أجزاء',surah:'سور',rub:'أرباع',ayahs:'آيات'};
const smartPlanWeekdayAr=['الأحد','الاثنين','الثلاثاء','الأربعاء','الخميس','الجمعة','السبت'];

Object.assign(state,{
  smartPlans:state.smartPlans||[],
  smartPlanEvents:state.smartPlanEvents||[],
  smartPlanRecitations:state.smartPlanRecitations||[],
  smartPlansAvailable:state.smartPlansAvailable??null,
  smartPlanError:state.smartPlanError||'',
  smartPlanTab:state.smartPlanTab||'dashboard',
  smartPlanHalaqa:state.smartPlanHalaqa||'all',
  smartPlanAutomationRunning:false,
});

function smartPlanMigrationMissing(error){let code=String(error?.code||''),msg=String(error?.message||'').toLowerCase();return ['42P01','PGRST205'].includes(code)||msg.includes('smart_plans')&&msg.includes('not find')}
function smartPlanDateOfRecord(record){let nested=Array.isArray(record?.sessions)?record.sessions[0]:record?.sessions;return String(record?.session_date||nested?.session_date||state.sessions.find(x=>x.id===record?.session_id)?.session_date||record?.created_at||'').slice(0,10)}
function smartPlanAllRecitations(){
  let withoutId=[],byId=new Map;
  const merge=(records=[],session=null)=>{
    for(let record of records||[]){
      let local=session?{...record,sessions:{session_date:session.session_date||smartPlanDateOfRecord(record),halaqa_id:session.halaqa_id||''}}:record;
      if(local?.id)byId.set(local.id,local);else withoutId.push(local);
    }
  };
  merge(state.smartPlanRecitations||[]);
  for(let [sessionId,cache] of Object.entries(state.offlineRosterCache||{})){
    let session=state.sessions.find(x=>String(x.id)===String(sessionId))||{};
    merge(cache?.recitations||[],session);
  }
  if(state.sessionView&&state.sessionRoster?.recitations?.length){
    let session=state.sessions.find(x=>String(x.id)===String(state.sessionView))||{};
    merge(state.sessionRoster.recitations,session);
  }
  return [...withoutId,...byId.values()];
}
function smartPlanEventsFor(planId,studentId){return (state.smartPlanEvents||[]).filter(x=>x.plan_id===planId&&(!studentId||x.student_id===studentId))}
const SMART_HIFZ_MIN_SURAH=2;
function smartPlanQuranLayout(){try{return (typeof loadQuranLayoutCache==='function'?loadQuranLayoutCache():null)||window.HALAQATI_QURAN_LAYOUT||null}catch(e){return window.HALAQATI_QURAN_LAYOUT||null}}
function smartPlanAyahLineKeys(surah,ayah,layout=smartPlanQuranLayout()){
  let s=Number(surah),a=Number(ayah);if(!layout||s<1||s>114||a<1||a>ayahCounts[s-1])return [];
  let g=globalAyah(s,a),page=Number(layout.page?.[g]||0),first=Number(layout.first?.[g]||0),last=Number(layout.last?.[g]||first);if(!page||!first)return [];
  let out=[];for(let line=first;line<=last;line++)out.push(`${page}:${line}`);return out
}
function smartPlanUniqueLineKeys(values=[]){let seen=new Set(),out=[];for(let value of values){let m=String(value||'').match(/^(\d{1,3}):(\d{1,2})$/);if(!m)continue;let page=+m[1],line=+m[2],key=`${page}:${line}`;if(page>=1&&page<=604&&line>=1&&line<=15&&!seen.has(key)){seen.add(key);out.push(key)}}return out}
function halaqatiQcfLineKeysForRecitation({mode,startSurah,startAyah,endSurah,endAyah,startPage,endPage}={}){
  let layout=smartPlanQuranLayout();if(!layout)return [];
  if(String(mode||'')==='ayahs'&&Number(startSurah)&&Number(startAyah)&&Number(endSurah)&&Number(endAyah)){
    let gs=globalAyah(+startSurah,+startAyah),ge=globalAyah(+endSurah,+endAyah);if(ge<gs)[gs,ge]=[ge,gs];let all=[];
    for(let g=gs;g<=ge;g++){let page=Number(layout.page?.[g]||0),first=Number(layout.first?.[g]||0),last=Number(layout.last?.[g]||first);for(let line=first;page&&line<=last;line++)all.push(`${page}:${line}`)}
    return smartPlanUniqueLineKeys(all)
  }
  let start=Number(startPage),end=Number(endPage);if(!Number.isInteger(start)&&Number.isInteger(end))start=end;if(!Number.isInteger(end)&&Number.isInteger(start))end=start;if(!Number.isInteger(start)||!Number.isInteger(end))return [];if(start>end)[start,end]=[end,start];let all=[];
  for(let page=Math.max(1,start);page<=Math.min(604,end);page++)for(let line=1;line<=15;line++)all.push(`${page}:${line}`);return all
}
window.halaqatiQcfLineKeysForRecitation=halaqatiQcfLineKeysForRecitation;
function smartPlanHifzPointText(point){return point?`${surahs[Number(point.surah)-1]} · آية ${fmt(point.ayah)}`:'نهاية مسار الحفظ'}
function nextReverseHifzPoint(surah,ayah){let s=Number(surah),a=Number(ayah);if(!Number.isInteger(s)||!Number.isInteger(a)||s<SMART_HIFZ_MIN_SURAH||s>114)return null;if(a<ayahCounts[s-1])return {surah:s,ayah:a+1};if(s>SMART_HIFZ_MIN_SURAH)return {surah:s-1,ayah:1};return null}
function finalizeReverseHifzRange(startSurah,startAyah,endSurah,endAyah,requestedPages,lineKeys,steps=[]){
  let pages=[...new Set(lineKeys.map(key=>Number(String(key).split(':')[0])).filter(Number.isInteger))],actual=Math.round((lineKeys.length/15)*100)/100;
  return {goal_unit:'pages',target_units:Number(requestedPages)||actual,target_pages:Math.max(.01,actual),range_start_page:pages.length?Math.min(...pages):null,range_end_page:pages.length?Math.max(...pages):null,range_start_surah:+startSurah,range_start_ayah:+startAyah,range_end_surah:+endSurah,range_end_ayah:+endAyah,selected_surahs:[],selected_juz:[],selected_rubs:[],lineKeys,steps,requestedPages:Number(requestedPages)||actual}
}
function buildReverseHifzRange(startSurah,startAyah,requestedPages){
  let layout=smartPlanQuranLayout();if(!layout?.page?.length)throw new Error('بيانات مصحف المدينة الدقيقة غير جاهزة بعد');let s=Number(startSurah),a=Number(startAyah),wanted=Number(requestedPages);if(!Number.isFinite(wanted)||wanted<=0)throw new Error('اكتب عدد الصفحات المطلوب');if(!Number.isInteger(s)||s<SMART_HIFZ_MIN_SURAH||s>114||!Number.isInteger(a)||a<1||a>ayahCounts[s-1])throw new Error('تحقق من سورة وآية البداية');
  let targetLines=Math.max(1,Math.ceil(wanted*15)),seen=new Set(),ordered=[],steps=[],endS=s,endA=a,done=false;
  for(let surah=s;surah>=SMART_HIFZ_MIN_SURAH&&!done;surah--){let firstAyah=surah===s?a:1;for(let ayah=firstAyah;ayah<=ayahCounts[surah-1];ayah++){
    let keys=smartPlanAyahLineKeys(surah,ayah,layout),newKeys=[];for(let key of keys)if(!seen.has(key)){seen.add(key);ordered.push(key);newKeys.push(key)};steps.push({surah,ayah,lineKeys:newKeys,allLineKeys:keys,page:keys[0]?+keys[0].split(':')[0]:null});endS=surah;endA=ayah;if(seen.size>=targetLines){done=true;break}
  }}
  let result=finalizeReverseHifzRange(s,a,endS,endA,wanted,ordered,steps);result.routeEnded=!done;return result
}
function buildReverseHifzRangeToEnd(startSurah,startAyah,endSurah,endAyah){
  let layout=smartPlanQuranLayout();if(!layout?.page?.length)return null;let s=Number(startSurah),a=Number(startAyah),es=Number(endSurah),ea=Number(endAyah);if(s<SMART_HIFZ_MIN_SURAH||es<SMART_HIFZ_MIN_SURAH||s>114||es>114)return null;
  let seen=new Set(),ordered=[],steps=[],found=false;for(let surah=s;surah>=SMART_HIFZ_MIN_SURAH&&!found;surah--){let firstAyah=surah===s?a:1;for(let ayah=firstAyah;ayah<=ayahCounts[surah-1];ayah++){
    let keys=smartPlanAyahLineKeys(surah,ayah,layout),newKeys=[];for(let key of keys)if(!seen.has(key)){seen.add(key);ordered.push(key);newKeys.push(key)};steps.push({surah,ayah,lineKeys:newKeys,allLineKeys:keys,page:keys[0]?+keys[0].split(':')[0]:null});if(surah===es&&ayah===ea){found=true;break}
  }}if(!found)return null;return finalizeReverseHifzRange(s,a,es,ea,ordered.length/15,ordered,steps)
}
function smartPlanSuggestedStart(student,excludePlanId=''){
  if(!student)return {surah:114,ayah:1,source:'default'};let passPlan={id:'__cursor__',plan_type:'hifz',target_pages:604,target_units:604,start_date:'1900-01-01',end_date:'2999-12-31',quality_gate_enabled:true,minimum_evaluation:'very_good'};
  let rows=smartPlanAllRecitations().filter(r=>String(r.student_id)===String(student.id)&&['new_hifz','hifz'].includes(String(r.activity_type||'').toLowerCase())&&Number(r.end_surah)&&Number(r.end_ayah)&&smartPlansEngine.isPassing(r,passPlan)).sort((a,b)=>{let da=smartPlanDateOfRecord(a),db=smartPlanDateOfRecord(b);return db.localeCompare(da)||String(b.created_at||'').localeCompare(String(a.created_at||''))});
  if(rows[0]){let next=nextReverseHifzPoint(rows[0].end_surah,rows[0].end_ayah);return next?{...next,source:'recitation',previous:{surah:+rows[0].end_surah,ayah:+rows[0].end_ayah}}:{surah:2,ayah:ayahCounts[1],source:'complete',complete:true}}
  let completed=(state.smartPlans||[]).filter(p=>p.id!==excludePlanId&&p.plan_type==='hifz'&&p.student_id===student.id&&Number(p.range_end_surah)&&Number(p.range_end_ayah)&&['completed','archived'].includes(p.status)).sort((a,b)=>String(b.updated_at||b.created_at||'').localeCompare(String(a.updated_at||a.created_at||'')))[0];
  if(completed){let next=nextReverseHifzPoint(completed.range_end_surah,completed.range_end_ayah);if(next)return {...next,source:'plan'}}return {surah:114,ayah:1,source:'default'}
}
function smartPlanStudentStoredRange(plan,student){let settings=plan?.settings||{};if(plan?.scope_type==='student')return plan;if(!student)return null;let item=settings.student_ranges?.[student.id];return item?{...plan,...item,settings:{...settings,...(item.settings||{})}}:null}
function materializeSmartPlan(plan,student){
  if(!plan||plan.plan_type!=='hifz')return plan;let row=smartPlanStudentStoredRange(plan,student);if(!row||!Number(row.range_start_surah)||!Number(row.range_end_surah))return plan.scope_type==='student'?plan:null;let exact=buildReverseHifzRangeToEnd(row.range_start_surah,row.range_start_ayah,row.range_end_surah,row.range_end_ayah);if(!exact)return row;
  return {...row,target_pages:Number(row.target_pages)||exact.target_pages,target_units:Number(row.target_units)||Number(row.settings?.requested_target_pages)||exact.target_pages,range_start_page:exact.range_start_page,range_end_page:exact.range_end_page,settings:{...(row.settings||{}),memorization_line_keys:exact.lineKeys,memorization_direction:'reverse_surahs_forward_ayahs',algorithm_version:'2.17.1'}}
}
function smartPlanProgress(plan,studentId,date=today()){let student=state.students.find(x=>String(x.id)===String(studentId)),materialized=materializeSmartPlan(plan,student);if(!materialized)materialized={...plan,target_units:plan.target_units||1,target_pages:plan.target_pages||1};let progress=smartPlansEngine.calculateProgress({plan:materialized,studentId,recitations:smartPlanAllRecitations(),sessions:state.sessions,events:smartPlanEventsFor(plan.id,studentId),today:date});progress.assignment=decorateSmartPlanAssignment(materialized,progress);return progress}
function effectiveSmartPlans(student,date=today()){return smartPlansEngine.effectivePlans(state.smartPlans||[],student,date).map(plan=>materializeSmartPlan(plan,student)).filter(Boolean)}
function activeSmartPlanStudents(plan){return activeStudents().filter(st=>{let scope=st.halaqa_id===plan.halaqa_id&&(plan.scope_type==='halaqa'||plan.scope_type==='category'&&st.category_id===plan.category_id||plan.scope_type==='student'&&st.id===plan.student_id);if(!scope)return false;if(plan.plan_type==='hifz'&&plan.scope_type!=='student')return !!plan.settings?.student_ranges?.[st.id];return true})}

function smartPlanActivityMatchesType(planType,activity){
  let map={hifz:['new_hifz','hifz'],review:['review','review_near','review_far'],sard:['sard','test'],tathbit:['tathbit','review_far']};
  return (map[planType]||[]).includes(String(activity||'').toLowerCase())
}
function smartPlanRangesOverlap(plan,startPage,endPage){
  let start=Number(startPage),end=Number(endPage);if(!Number.isFinite(start)||!Number.isFinite(end))return true;if(start>end)[start,end]=[end,start];
  let ps=Number(plan.range_start_page),pe=Number(plan.range_end_page);if(!Number.isFinite(ps)||!Number.isFinite(pe))return true;
  return end>=ps&&start<=pe
}
function resolveSmartPlanForRecitation({studentId,sessionId,activityType,startPage,endPage}={}){
  let student=state.students.find(x=>String(x.id)===String(studentId)),session=state.sessions.find(x=>String(x.id)===String(sessionId));if(!student||!session)return null;
  return effectiveSmartPlans(student,session.session_date).find(plan=>smartPlanActivityMatchesType(plan.plan_type,activityType)&&smartPlanRangesOverlap(plan,startPage,endPage))||null
}
window.halaqatiResolveSmartPlanForRecitation=resolveSmartPlanForRecitation;

const smartPlanBaseSaveReportOffline=saveReportOffline;
saveReportOffline=function(payload){
  smartPlanBaseSaveReportOffline(payload);
  let session=state.sessions.find(x=>String(x.id)===String(payload?.sessionId))||{},cache=state.offlineRosterCache?.[payload?.sessionId];
  if(cache?.recitations?.length){
    let byId=new Map((state.smartPlanRecitations||[]).filter(x=>x?.id).map(x=>[x.id,x])),without=(state.smartPlanRecitations||[]).filter(x=>!x?.id);
    for(let record of cache.recitations){let item={...record,sessions:{session_date:session.session_date||smartPlanDateOfRecord(record),halaqa_id:session.halaqa_id||''}};if(item.id)byId.set(item.id,item);else without.push(item)}
    state.smartPlanRecitations=[...without,...byId.values()].slice(-10000)
  }
};


const smartPlanBaseCacheSnapshot=cacheSnapshot;
cacheSnapshot=function(){
  smartPlanBaseCacheSnapshot();
  if(!state.profile)return;
  let snap=state.offlineSnapshotCache||readJsonLocal(cacheKey(),{})||{};
  Object.assign(snap,{smartPlans:state.smartPlans||[],smartPlanEvents:state.smartPlanEvents||[],smartPlanRecitations:(state.smartPlanRecitations||[]).slice(-10000),smartPlansAvailable:state.smartPlansAvailable,smartPlanError:state.smartPlanError||'',smartPlanTab:state.smartPlanTab,smartPlanHalaqa:state.smartPlanHalaqa});
  state.offlineSnapshotCache=cloneJson(snap);let k=cacheKey();try{if(k)localStorage.setItem(k,JSON.stringify(snap))}catch(e){}
  let store=window.HalaqatiOfflineStore;if(store?.putSnapshot&&state.user?.id)store.putSnapshot(state.user.id,snap).catch(e=>console.warn('Smart plans snapshot write failed',e))
};

const smartPlanBaseRestoreSnapshot=restoreSnapshot;
restoreSnapshot=function(){
  let ok=smartPlanBaseRestoreSnapshot();if(!ok)return false;
  let snap=state.offlineSnapshotCache||readJsonLocal(cacheKey(),null)||readJsonLocal(legacyCacheKey(),null)||{};
  state.smartPlans=snap.smartPlans||[];state.smartPlanEvents=snap.smartPlanEvents||[];state.smartPlanRecitations=snap.smartPlanRecitations||[];state.smartPlansAvailable=snap.smartPlansAvailable??(state.smartPlans.length?true:null);state.smartPlanError=snap.smartPlanError||'';state.smartPlanTab=snap.smartPlanTab||'dashboard';state.smartPlanHalaqa=snap.smartPlanHalaqa||'all';return true
};

async function loadSmartPlanData(){
  if(!state.user?.id||!state.networkVerified)return;
  let plans=await db.from('smart_plans').select('*').neq('status','archived').order('created_at',{ascending:false}).limit(1000);
  if(plans.error){state.smartPlansAvailable=false;state.smartPlanError=plans.error.message||'';if(!smartPlanMigrationMissing(plans.error))console.warn('Smart plans unavailable',plans.error);cacheSnapshot();return}
  let v217=await db.from('smart_plans').select('id,category_id').limit(1);
  if(v217.error){state.smartPlansAvailable=false;state.smartPlanError='ترحيل v2.17 غير مطبق بعد: '+(v217.error.message||'category_id غير موجود');cacheSnapshot();return}
  state.smartPlansAvailable=true;state.smartPlanError='';state.smartPlans=plans.data||[];
  let planIds=state.smartPlans.map(x=>x.id),events=planIds.length?await db.from('smart_plan_events').select('*').in('plan_id',planIds).order('event_date',{ascending:false}).limit(3000):{data:[],error:null};
  if(events.error)console.warn('Smart plan events load skipped',events.error);else state.smartPlanEvents=events.data||[];
  let recitations=await db.from('recitation_entries').select('*,sessions!inner(session_date,halaqa_id)').order('created_at',{ascending:false}).limit(10000);
  if(recitations.error){console.warn('Smart plan recitations load skipped',recitations.error)}else state.smartPlanRecitations=(recitations.data||[]).reverse();
  await runSmartPlanAutoExtensions();cacheSnapshot();setTimeout(()=>checkSmartPlanAlerts(),900)
}

const smartPlanBaseLoadAll=loadAll;
loadAll=async function(forceNetwork=false){await smartPlanBaseLoadAll(forceNetwork);if(state.networkVerified&&!state.offline)await loadSmartPlanData()};

const SMART_PLAN_DB_COLUMNS=new Set(['id','scope_type','halaqa_id','student_id','category_id','parent_plan_id','plan_type','review_tier','title','goal_unit','target_units','target_pages','start_date','end_date','schedule_weekdays','catch_up_weekday','max_daily_multiplier','auto_extend','quality_gate_enabled','minimum_evaluation','range_start_page','range_end_page','range_start_surah','range_start_ayah','range_end_surah','range_end_ayah','selected_surahs','selected_juz','selected_rubs','near_revision_pages','far_revision_pages','milestone_mode','milestone_requires_approval','delay_alert_days','home_prep_push','status','note','settings','revision','created_by','created_at','updated_at']);
function cleanSmartPlanRow(row){let out={};for(let [key,value] of Object.entries(row||{}))if(SMART_PLAN_DB_COLUMNS.has(key))out[key]=value;return out}
function normalizeSmartPlanRequestedPages(value,{writeBack=false}={}){let n=Number(value);if(!Number.isFinite(n)||n<=0)return 0;let rounded=Math.min(604,Math.max(1,Math.ceil(n-1e-9)));if(writeBack&&$('#spHifzTargetPages'))$('#spHifzTargetPages').value=String(rounded);return rounded}
window.normalizeSmartPlanRequestedPages=normalizeSmartPlanRequestedPages;
async function applySmartPlanOfflineOperation(op){
  if(op.type==='smart_plan_upsert'){
    let mode=op.payload?.mode||'update',obj=cleanSmartPlanRow(op.payload?.row||op.payload||op.obj||{}),result;
    if(mode==='insert'){
      result=await db.from('smart_plans').insert(obj).select().single();
      if(result.error&&String(result.error.code)==='23505')result=await db.from('smart_plans').select('*').eq('id',obj.id).single()
    }else result=await db.from('smart_plans').update(obj).eq('id',obj.id).select().single();
    if(result.error)throw result.error;
    let index=state.smartPlans.findIndex(x=>x.id===result.data.id);if(index>=0)state.smartPlans[index]=result.data;else state.smartPlans.push(result.data);return
  }
  if(op.type==='smart_plan_event'){
    let obj=cleanSmartPlanRow(op.payload||{}),result=await db.from('smart_plan_events').insert(obj).select().single();if(result.error&&String(result.error.code)!=='23505')throw result.error;
    let saved=result.data||obj,index=state.smartPlanEvents.findIndex(x=>x.client_event_id===saved.client_event_id);if(index>=0)state.smartPlanEvents[index]=saved;else state.smartPlanEvents.push(saved);return
  }
}
const smartPlanBaseApplyOfflineOperation=applyOfflineOperation;
applyOfflineOperation=async function(op,map){if(op.type==='smart_plan_upsert'||op.type==='smart_plan_event')return await applySmartPlanOfflineOperation(op,map);return await smartPlanBaseApplyOfflineOperation(op,map)};
const smartPlanBaseSyncOperationLabel=syncOperationLabel;
syncOperationLabel=function(op){if(op.type==='smart_plan_upsert')return 'خطة ذكية';if(op.type==='smart_plan_event')return 'حدث خطة ذكية';return smartPlanBaseSyncOperationLabel(op)};
const smartPlanBaseOfflinePriority=offlineOperationPriority;
offlineOperationPriority=function(op){if(op.type==='smart_plan_upsert')return 35;if(op.type==='smart_plan_event')return 55;return smartPlanBaseOfflinePriority(op)};

function saveSmartPlanLocal(plan,{announce=true}={}){
  let index=state.smartPlans.findIndex(x=>x.id===plan.id),previous=index>=0?state.smartPlans[index]:null,mode=previous?._syncMode||(!previous?'insert':'update'),local={...plan,_offline:true,_syncMode:mode};if(index>=0)state.smartPlans[index]=local;else state.smartPlans.unshift(local);
  enqueueOffline({type:'smart_plan_upsert',key:`smart-plan:${plan.id}`,dedupeKey:`smart-plan:${plan.id}`,payload:{mode,row:cleanSmartPlanRow(plan)}});if(announce)toast('تم حفظ الخطة محلياً وستتزامن تلقائياً');if(navigator.onLine)setTimeout(()=>syncOfflineQueue({refreshAfter:false}),40)
}
function recordSmartPlanEvent(planId,studentId,eventType,payload={}){
  let event={id:offlineUuid(),client_event_id:offlineUuid(),plan_id:planId,student_id:studentId,event_type:eventType,event_date:today(),payload,created_by:state.user.id,created_at:new Date().toISOString(),_offline:true};state.smartPlanEvents.unshift(event);enqueueOffline({type:'smart_plan_event',key:`smart-plan-event:${event.client_event_id}`,dedupeKey:`smart-plan-event:${event.client_event_id}`,payload:cleanSmartPlanRow(event)});return event
}

async function runSmartPlanAutoExtensions(){
  if(state.smartPlanAutomationRunning||!roleCanManage()||!state.smartPlansAvailable)return;state.smartPlanAutomationRunning=true;
  try{
    for(let plan of (state.smartPlans||[]).filter(x=>x.status==='active'&&x.auto_extend!==false)){
      let updates=activeSmartPlanStudents(plan).map(student=>({student,progress:smartPlanProgress(plan,student.id)})).filter(x=>x.progress.extensionNeeded);
      if(!updates.length)continue;let nextEnd=updates.map(x=>x.progress.suggestedEndDate).sort().at(-1);if(!nextEnd||nextEnd<=plan.end_date)continue;
      let previous=plan.end_date,updated={...plan,end_date:nextEnd,updated_at:new Date().toISOString()};saveSmartPlanLocal(updated,{announce:false});for(let item of updates)recordSmartPlanEvent(plan.id,item.student.id,'auto_extension',{old_end_date:previous,new_end_date:nextEnd,uncovered_deficit:item.progress.deficit})
    }
  }finally{state.smartPlanAutomationRunning=false}
}

function smartPlanHifzSteps(plan){if(plan?.plan_type!=='hifz'||!Number(plan.range_start_surah)||!Number(plan.range_end_surah))return [];return buildReverseHifzRangeToEnd(plan.range_start_surah,plan.range_start_ayah,plan.range_end_surah,plan.range_end_ayah)?.steps||[]}
function smartPlanSegmentsFromSteps(steps=[]){let segments=[];for(let step of steps){let last=segments.at(-1);if(last&&last.surah===step.surah&&step.ayah===last.endAyah+1)last.endAyah=step.ayah;else segments.push({surah:step.surah,startAyah:step.ayah,endAyah:step.ayah})}return segments}
function smartPlanSegmentsText(segments=[]){return segments.map(seg=>`${surahs[seg.surah-1]} ${fmt(seg.startAyah)}${seg.endAyah!==seg.startAyah?`–${fmt(seg.endAyah)}`:''}`).join('، ')||'—'}
function smartPlanPlanRangeText(plan){if(plan?.plan_type==='hifz'&&Number(plan.range_start_surah)&&Number(plan.range_end_surah))return `${smartPlanHifzPointText({surah:plan.range_start_surah,ayah:plan.range_start_ayah})} ← ${smartPlanHifzPointText({surah:plan.range_end_surah,ayah:plan.range_end_ayah})}`;return smartPlanRangeText(plan?.range_start_page,plan?.range_end_page)}
function decorateSmartPlanAssignment(plan,progress){let base=progress?.assignment||{};if(plan?.plan_type!=='hifz'||!progress?.linePlan||base.milestone)return base;let steps=smartPlanHifzSteps(plan),wanted=new Set(base.blockedByRetry?(progress.retryLineKeys||[]):[]),completed=new Set(progress.completedLineKeys||[]),picked=[],lineSet=new Set(),needed=Math.max(0,Math.ceil(Number(base.pages||0)*15));
  for(let step of steps){let keys=step.allLineKeys?.length?step.allLineKeys:step.lineKeys||[],relevant=base.blockedByRetry?keys.some(k=>wanted.has(k)):keys.some(k=>!completed.has(k));if(!relevant)continue;picked.push(step);for(let key of keys){if(base.blockedByRetry?!wanted.has(key):completed.has(key))continue;lineSet.add(key)}if(!base.blockedByRetry&&lineSet.size>=needed)break}
  let segments=smartPlanSegmentsFromSteps(picked),pages=Math.round((lineSet.size/15)*100)/100;return {...base,ayahSegments:segments,ayahLabel:smartPlanSegmentsText(segments),pages:pages||base.pages,scheduledPages:base.pages,startPage:picked[0]?.page||base.startPage,endPage:picked.at(-1)?.page||base.endPage}
}
function smartPlanRangeText(start,end){if(!start)return 'لا يوجد مقدار اليوم';return start===end?`صفحة ${fmt(start)}`:`الصفحات ${fmt(start)}–${fmt(end)}`}
function smartPlanRangesText(ranges=[]){return ranges.map(x=>x.start===x.end?fmt(x.start):`${fmt(x.start)}–${fmt(x.end)}`).join('، ')||'—'}
function smartPlanAssignmentLabel(assignment){if(!assignment)return 'لا يوجد مقرر';let kind={hifz:'حفظ',review:'مراجعة',sard:'سرد',tathbit:'تثبيت إجباري',test:'اختبار مرحلي'}[assignment.kind]||'مقرر';return `${kind}: ${assignment.ayahLabel||smartPlanRangeText(assignment.startPage,assignment.endPage)}`}
function smartPlanHealthBadge(progress){return `<span class="smart-health ${progress.health}">${progress.health==='green'?'●':progress.health==='yellow'?'▲':'!'} ${progress.healthLabel}</span>`}
function smartPlanProgressBar(progress){let percent=Math.max(0,Math.min(100,Number(progress.percentage)||0));return `<div class="smart-progress"><div class="smart-progress-head"><span>${fmt(progress.completed)} من ${fmt(progress.plan.target_pages)} صفحة</span><b>${fmt(percent)}%</b></div><div class="smart-progress-track"><i style="width:${percent}%"></i></div></div>`}

function smartPlanReviewSuggestions(student,date=today(),plan=null){let tier=plan?.review_tier||'both',suggestions=smartPlansEngine.reviewSuggestions({studentId:student.id,recitations:smartPlanAllRecitations(),sessions:state.sessions,nearPages:plan?.near_revision_pages??7,farPages:plan?.far_revision_pages??20,today:date});let day=new Date(`${date}T00:00:00Z`).getUTCDay(),firstDay=[...(plan?.schedule_weekdays||[0])].sort((a,b)=>a-b)[0],farDue=tier==='far'||tier==='both'&&(day===plan?.catch_up_weekday||day===firstDay);return {nearRanges:tier==='far'?[]:suggestions.nearRanges,farRanges:farDue?suggestions.farRanges:[],farDue}}
function smartPlanMonthTarget(plan,date=today()){let ym=String(date).slice(0,7),all=smartPlansEngine.planDates(plan),month=all.filter(x=>x.startsWith(ym));return all.length?Number(plan.target_pages||0)*month.length/all.length:0}
function smartPlanWeekRequirement(plan,progress,date=today()){let end=smartPlansEngine.addDays(date,6),weekDays=smartPlansEngine.planDates(plan,date,end).length,futureDays=smartPlansEngine.planDates(plan,date,plan.end_date).length,amount=Math.min(progress.remaining,weekDays*progress.originalDaily+(futureDays?progress.deficit*weekDays/futureDays:0));if(plan.range_start_page&&amount>0)amount=Math.min(progress.remaining,Math.ceil(amount));let start=progress.assignment.blockedByRetry||progress.assignment.milestone?progress.assignment.startPage:progress.nextPage,finish=start&&amount?Math.min(plan.range_end_page||604,start+Math.max(1,Math.ceil(amount))-1):null;return {amount,startPage:start,endPage:finish}}

function smartPlanStudentPanel(student,date=today(),compact=false){
  let plans=effectiveSmartPlans(student,date);if(!plans.length)return compact?'<div class="smart-plan-empty">لا توجد خطة فعالة لهذا اليوم.</div>':`<div class="card smart-student-plan"><div class="section-head"><h3>الخطة الذكية</h3>${roleCanManage()?`<button class="mini" onclick="openPlan('${student.id}')">+ إنشاء خطة</button>`:''}</div><div class="empty">لا توجد خطة فعالة لهذا الطالب.</div></div>`;
  let rows=plans.map(plan=>{let progress=smartPlanProgress(plan,student.id,date),a=progress.assignment,week=smartPlanWeekRequirement(plan,progress,date),review=plan.plan_type==='review'?smartPlanReviewSuggestions(student,date,plan):null;return `<div class="smart-plan-track ${progress.health}"><div class="smart-track-title"><div><b>${esc(plan.title||smartPlanTypeAr[plan.plan_type])}</b><small>${smartPlanTypeAr[plan.plan_type]} · ${smartPlanPlanRangeText(plan)}</small></div>${smartPlanHealthBadge(progress)}</div>${smartPlanProgressBar(progress)}<div class="smart-kpis"><span><b>${fmt(plan.settings?.requested_target_pages??plan.target_pages)}</b>هدف الخطة</span><span><b>${fmt(progress.remaining)}</b>المتبقي</span><span><b>${progress.paceLabel}</b>الحالة</span><span><b>${fmt(progress.assignment.pages)}</b>مطلوب اليوم</span></div><div class="smart-today"><b>${smartPlanAssignmentLabel(a)}</b><span>مطلوب هذا الأسبوع: ${fmt(week.amount)} صفحة · ${smartPlanRangeText(week.startPage,week.endPage)}</span>${a.blockedByRetry?'<span>توقّف الحفظ الجديد حتى اجتياز التثبيت.</span>':''}${a.milestone?`<span>${esc(a.milestone.label)} بانتظار اعتماد المحفّظ.</span>`:''}${review?`<span>قريب: ${smartPlanRangesText(review.nearRanges)}${review.farDue?` · بعيد: ${smartPlanRangesText(review.farRanges)}`:''}</span>`:''}</div>${progress.extensionNeeded?`<div class="smart-extension">تمديد آمن مقترح حتى ${progress.suggestedEndDate} بدل رفع الورد فوق ${fmt(progress.dailyCap)} صفحة.</div>`:''}${roleCanManage()?`<div class="plan-card-actions"><button class="mini" onclick="openPlan('${student.id}','${plan.id}')">تعديل</button><button class="mini red" onclick="archiveSmartPlan('${plan.id}')">أرشفة</button></div>`:''}</div>`}).join('');
  return compact?rows:`<div class="card smart-student-plan"><div class="section-head"><h3>الخطة الذكية · ${esc(student.full_name)}</h3>${roleCanManage()?`<button class="mini" onclick="openPlan('${student.id}')">+ مسار</button>`:''}</div>${rows}</div>`
}

function smartPlanReportRows(){
  let result=[];
  for(let student of activeStudents())for(let plan of effectiveSmartPlans(student)){if(state.smartPlanHalaqa!=='all'&&student.halaqa_id!==state.smartPlanHalaqa)continue;result.push({student,plan,progress:smartPlanProgress(plan,student.id)})}
  return result
}
function smartPlanReportsHtml(){
  let rows=smartPlanReportRows(),best=[...rows].sort((a,b)=>b.progress.percentage-a.progress.percentage).slice(0,8),delayed=rows.filter(x=>x.progress.health!=='green').sort((a,b)=>a.progress.percentage-b.progress.percentage),halaqas=state.halaqas.map(h=>{let r=rows.filter(x=>x.student.halaqa_id===h.id),target=r.reduce((s,x)=>s+Number(x.plan.target_pages||0),0),done=r.reduce((s,x)=>s+x.progress.completed,0);return {h,r,target,done,pct:target?done/target*100:0}}).filter(x=>x.r.length);let byType=Object.keys(smartPlanTypeAr).map(type=>{let r=rows.filter(x=>x.plan.plan_type===type);return {type,planned:r.reduce((s,x)=>s+x.progress.plannedByToday,0),done:r.reduce((s,x)=>s+x.progress.completed,0)}}).filter(x=>x.planned||x.done);
  return `<div class="smart-report-grid"><div class="card"><h3>أفضل التزام</h3>${best.map((x,i)=>`<div class="smart-report-row"><b>${i+1}. ${esc(x.student.full_name)}</b><span>${fmt(x.progress.percentage)}%</span></div>`).join('')||'<div class="empty">لا توجد بيانات.</div>'}</div><div class="card"><h3>الطلاب المتأخرون</h3>${delayed.map(x=>`<div class="smart-report-row"><span><b>${esc(x.student.full_name)}</b><small>${x.progress.consecutiveMissed} أيام متتالية · ${smartPlanTypeAr[x.plan.plan_type]}</small></span>${smartPlanHealthBadge(x.progress)}</div>`).join('')||'<div class="empty">كل الخطط ضمن المسار السليم.</div>'}</div></div><div class="card"><h3>نسبة إنجاز الحلقات</h3>${halaqas.map(x=>`<div class="smart-halaqa-report"><div><b>${esc(x.h.name)}</b><span>${x.r.length} مسار فعال</span></div><div class="smart-progress-track"><i style="width:${Math.min(100,x.pct)}%"></i></div><b>${fmt(x.pct)}%</b></div>`).join('')||'<div class="empty">لا توجد خطط.</div>'}</div><div class="card"><h3>المخطط مقابل المنجز حتى اليوم</h3><div class="smart-compare">${byType.map(x=>`<div><b>${smartPlanTypeAr[x.type]}</b><span>المخطط ${fmt(x.planned)} ص</span><i style="--ratio:${Math.min(100,x.planned?x.done/x.planned*100:0)}%"></i><strong>${fmt(x.done)} منجز</strong></div>`).join('')}</div></div>`
}

function smartPlanAutomationNotices(){let rows=(state.smartPlanEvents||[]).filter(x=>x.event_type==='auto_extension').slice(0,4);if(!rows.length)return '';return `<div class="smart-automation-notices"><b>تنبيهات المحرك الذكي</b>${rows.map(event=>{let plan=state.smartPlans.find(x=>x.id===event.plan_id),student=state.students.find(x=>x.id===event.student_id),payload=event.payload||{};return `<span>تم تمديد «${esc(plan?.title||'الخطة')}» للطالب ${esc(student?.full_name||'—')} من ${esc(payload.old_end_date||'—')} إلى ${esc(payload.new_end_date||'—')} لأن العجز تجاوز سقف التعويض الآمن.</span>`}).join('')}</div>`}

function plansPage(){
  if(state.smartPlansAvailable===false)return `<div class="hero"><h2>الخطط الذكية v2.17</h2><p>المحرك جاهز، وتبقى تهيئة جدولي الخطط والأحداث على Supabase.</p></div><div class="notice"><b>طبّق ترحيل قاعدة البيانات أولاً:</b><br>supabase/migrations/20260831_v217_smart_plan_categories_admin_delete.sql${state.smartPlanError?`<br><span class="muted">${esc(state.smartPlanError)}</span>`:''}</div>`;
  let students=activeStudents().filter(x=>state.smartPlanHalaqa==='all'||x.halaqa_id===state.smartPlanHalaqa),rows=smartPlanReportRows(),avg=rows.length?rows.reduce((s,x)=>s+x.progress.percentage,0)/rows.length:0,behind=rows.filter(x=>x.progress.health!=='green').length,groups=(state.smartPlans||[]).filter(x=>['halaqa','category'].includes(x.scope_type)&&x.status!=='archived'&&(state.smartPlanHalaqa==='all'||x.halaqa_id===state.smartPlanHalaqa));
  let controls=roleCanManage()?`<div class="smart-plan-tabs"><button class="${state.smartPlanTab==='dashboard'?'active':''}" onclick="state.smartPlanTab='dashboard';render()">لوحة الخطط</button><button class="${state.smartPlanTab==='reports'?'active':''}" onclick="state.smartPlanTab='reports';render()">تقارير الخطط</button></div><label class="field smart-plan-filter"><span>الحلقة</span><select onchange="state.smartPlanHalaqa=this.value;render()"><option value="all">كل الحلقات</option>${state.halaqas.map(h=>`<option value="${h.id}" ${state.smartPlanHalaqa===h.id?'selected':''}>${esc(h.name)}</option>`).join('')}</select></label>`:'';
  if(state.smartPlanTab==='reports'&&roleCanManage())return `<div class="hero"><h2>تقارير الخطط الذكية</h2><p>أفضل التزام، حالات التعثر، إنجاز الحلقات، والمخطط مقابل المنجز الفعلي.</p></div>${controls}${smartPlanAutomationNotices()}${smartPlanReportsHtml()}`;
  let groupHtml=groups.length?`<div class="section-head"><h3>الخطط الجماعية</h3></div>${groups.map(plan=>{let members=activeSmartPlanStudents(plan),progress=members.map(s=>smartPlanProgress(plan,s.id)),mean=progress.length?progress.reduce((a,x)=>a+x.percentage,0)/progress.length:0;let scopeLabel=plan.scope_type==='category'?`فئة: ${esc(state.categories.find(x=>x.id===plan.category_id)?.name||'—')}`:'الحلقة كلها';return `<div class="card smart-group-plan"><div class="row"><div class="avatar">ح</div><div class="grow"><b>${esc(plan.title)}</b><div class="muted">${esc(state.halaqas.find(x=>x.id===plan.halaqa_id)?.name||'')} · ${scopeLabel} · ${smartPlanTypeAr[plan.plan_type]} · ${members.length} طالب</div></div><span class="badge blue">${plan.scope_type==='category'?'فئة':'جماعية'}</span></div><div class="smart-kpis"><span><b>${fmt(plan.target_pages)}</b>الهدف/طالب</span><span><b>${fmt(mean)}%</b>متوسط الإنجاز</span><span><b>${progress.filter(x=>x.health==='red').length}</b>خطر تعثر</span><span><b>${plan.end_date}</b>النهاية</span></div><div class="plan-card-actions"><button class="mini" onclick="openPlan('','${plan.id}')">تعديل الخطة</button><button class="mini" onclick="openSmartPlanOverride('${plan.id}')">تخصيص لطالب</button><button class="mini red" onclick="archiveSmartPlan('${plan.id}')">أرشفة</button></div></div>`}).join('')}`:'';
  return `<div class="hero"><h2>الخطط الذكية v2.17</h2><p>خطط حفظ ومراجعة وسرد وتثبيت مرتبطة بصفحات المصحف، تتحدث تلقائياً من التسميع وتعمل دون إنترنت.</p></div>${controls}${roleCanManage()?smartPlanAutomationNotices():''}<div class="grid stats">${stat('المسارات الفعالة',rows.length)}${stat('متوسط الإنجاز',fmt(avg)+'%')}${stat('بحاجة متابعة',behind)}${stat('خطط الفئات/الحلقات',groups.length)}</div>${groupHtml}<div class="section-head"><h3>${state.profile?.role==='guardian'?'خطط أبنائي':'خطط الطلاب'}</h3>${roleCanManage()?'<button class="btn btn-primary" onclick="openPlan()">+ خطة ذكية</button>':''}</div>${students.map(student=>smartPlanStudentPanel(student,today(),false)).join('')||'<div class="empty">لا يوجد طلاب في هذا النطاق.</div>'}`
}

function smartPlanScopeStudentsFromForm(){let scope=$('#spScope').value,hid=$('#spHalaqa').value;if(scope==='student'){let st=state.students.find(x=>x.id===$('#spStudent').value);return st?[st]:[]}if(scope==='category'){let cid=$('#spCategory').value;return activeStudents().filter(x=>x.halaqa_id===hid&&x.category_id===cid)}return activeStudents().filter(x=>x.halaqa_id===hid)}
function updateSmartPlanScope(){let scope=$('#spScope').value;$('#spStudentField').classList.toggle('hidden',scope!=='student');$('#spCategoryField').classList.toggle('hidden',scope!=='category');$('#spStudent').required=scope==='student';$('#spCategory').required=scope==='category';updateSmartPlanHifzStartMode();previewSmartPlanEstimate()}
function updateSmartPlanStudents(){let hid=$('#spHalaqa').value,current=$('#spStudent').value,rows=activeStudents().filter(x=>x.halaqa_id===hid);$('#spStudent').innerHTML=rows.map(x=>`<option value="${x.id}">${esc(x.full_name)}</option>`).join('');if(rows.some(x=>x.id===current))$('#spStudent').value=current;else if(rows[0])$('#spStudent').value=rows[0].id;refreshSmartPlanSuggestedStart()}
function updateSmartPlanCategories(){let hid=$('#spHalaqa').value,current=$('#spCategory').value,rows=(state.categories||[]).filter(x=>x.halaqa_id===hid&&x.active!==false);$('#spCategory').innerHTML=rows.map(x=>`<option value="${x.id}">${esc(x.name)}</option>`).join('');if(rows.some(x=>x.id===current))$('#spCategory').value=current;else if(rows[0])$('#spCategory').value=rows[0].id;previewSmartPlanEstimate()}
function updateSmartPlanTypeFields(){let type=$('#spType').value,review=type==='review',hifz=type==='hifz';$('#spReviewFields').classList.toggle('hidden',!review);$('#spHifzFields').classList.toggle('hidden',!hifz);$('#spClassicRangeFields').classList.toggle('hidden',hifz);if(hifz)refreshSmartPlanSuggestedStart();else previewSmartPlanEstimate()}
function smartPlanOptions(max,labelFn=x=>x){return Array.from({length:max},(_,index)=>{let value=index+1;return `<option value="${value}">${esc(labelFn(value))}</option>`}).join('')}
function smartPlanReverseSurahOptions(){let html='';for(let s=114;s>=SMART_HIFZ_MIN_SURAH;s--)html+=`<option value="${s}">${s}. ${esc(surahs[s-1])}</option>`;return html}
function updateSmartPlanHifzAyahLimit(){let surah=Number($('#spHifzStartSurah').value)||114,input=$('#spHifzStartAyah');input.max=ayahCounts[surah-1];if(+input.value<1)input.value=1;if(+input.value>+input.max)input.value=input.max;previewSmartPlanEstimate()}
function updateSmartPlanHifzStartMode(){let hifz=$('#spType')?.value==='hifz';if(!hifz)return;let auto=$('#spHifzStartMode').value==='auto',scope=$('#spScope').value,hide=auto&&scope!=='student';$('#spHifzStartSurahField').classList.toggle('hidden',hide);$('#spHifzStartAyahField').classList.toggle('hidden',hide);$('#spHifzStartSurah').disabled=auto&&scope==='student';$('#spHifzStartAyah').disabled=auto&&scope==='student';refreshSmartPlanSuggestedStart()}
function refreshSmartPlanSuggestedStart(){let type=$('#spType')?.value,box=$('#spHifzStartHint');if(type!=='hifz'||!box)return;let scope=$('#spScope').value,auto=$('#spHifzStartMode').value==='auto';if(!auto){box.textContent='سيبدأ جميع الطلاب في هذا النطاق من الموضع اليدوي المحدد.';previewSmartPlanEstimate();return}if(scope==='student'){let student=state.students.find(x=>x.id===$('#spStudent').value),point=smartPlanSuggestedStart(student,$('#spId').value);if(point.complete){box.textContent='الطالب وصل إلى نهاية مسار الحفظ حتى البقرة. غيّر البداية يدوياً إذا كان المقصود إعادة دورة جديدة.'}else{if(point.surah){$('#spHifzStartSurah').value=String(point.surah);$('#spHifzStartAyah').value=String(point.ayah);updateSmartPlanHifzAyahLimit()}box.textContent=point.source==='recitation'?`البداية المقترحة بعد آخر حفظ ناجح: ${smartPlanHifzPointText(point)}`:point.source==='plan'?`البداية المقترحة بعد آخر خطة مكتملة: ${smartPlanHifzPointText(point)}`:`لا يوجد حفظ سابق محدد بالآيات؛ البداية الافتراضية: ${smartPlanHifzPointText(point)}`}}else{let count=smartPlanScopeStudentsFromForm().length;box.textContent=`سيحسب التطبيق بداية مستقلة لكل طالب من آخر حفظ ناجح لديه (${count} طالب في النطاق).`;}previewSmartPlanEstimate()}
function updateSmartPlanRangeFields(preserve={}){
  let unit=$('#spGoalUnit').value,simple=unit!=='ayahs';$('#spSimpleRange').classList.toggle('hidden',!simple);$('#spAyahRange').classList.toggle('hidden',simple);
  if(simple){let config=unit==='pages'?[604,'من صفحة','إلى صفحة',x=>x]:unit==='juz'?[30,'من جزء','إلى جزء',x=>`الجزء ${x}`]:unit==='rub'?[240,'من ربع','إلى ربع',x=>`الربع ${x}`]:[114,'من سورة','إلى سورة',x=>`${x}. ${surahs[x-1]}`];$('#spRangeStartLabel').textContent=config[1];$('#spRangeEndLabel').textContent=config[2];$('#spRangeStart').innerHTML=smartPlanOptions(config[0],config[3]);$('#spRangeEnd').innerHTML=smartPlanOptions(config[0],config[3]);$('#spRangeStart').value=String(preserve.start||1);$('#spRangeEnd').value=String(preserve.end||Math.min(config[0],unit==='pages'?5:1))}
  previewSmartPlanEstimate()
}
function updateSmartPlanAyahLimits(side){let surah=Number($('#sp'+(side==='start'?'Start':'End')+'Surah').value)||1,input=$('#sp'+(side==='start'?'Start':'End')+'Ayah');input.max=ayahCounts[surah-1];if(Number(input.value)>Number(input.max))input.value=input.max;previewSmartPlanEstimate()}
function selectedSmartPlanWeekdays(){return $$('input[name="spWeekday"]:checked').map(x=>Number(x.value)).sort((a,b)=>a-b)}
function smartPlanRangeFromForm(){let unit=$('#spGoalUnit').value;if(unit==='ayahs')return smartPlansEngine.quranRangeFromSelection({goal_unit:unit,start_surah:+$('#spStartSurah').value,start_ayah:+$('#spStartAyah').value,end_surah:+$('#spEndSurah').value,end_ayah:+$('#spEndAyah').value});return smartPlansEngine.quranRangeFromSelection({goal_unit:unit,start_value:+$('#spRangeStart').value,end_value:+$('#spRangeEnd').value})}
function smartPlanDistributionText(targetPages,days){let target=Math.max(0,Math.round(Number(targetPages)||0)),count=Math.max(1,Number(days)||1),base=Math.floor(target/count),extra=target-(base*count);if(!target)return 'لا يوجد مقدار';if(base===0)return `${target} صفحة موزعة على ${target} يوم من أصل ${count} يوم دوام`;if(!extra)return `${base} صفحة كل يوم دوام`;return `${base} صفحة يومياً + صفحة إضافية في ${extra} أيام`}
function smartPlanHifzRangeFromFormForStudent(student){let requested=normalizeSmartPlanRequestedPages($('#spHifzTargetPages').value),auto=$('#spHifzStartMode').value==='auto',scope=$('#spScope').value,point=auto?smartPlanSuggestedStart(student,$('#spId').value):{surah:+$('#spHifzStartSurah').value,ayah:+$('#spHifzStartAyah').value};if(auto&&scope!=='student'&&!student)point={surah:114,ayah:1};if(point?.complete)throw new Error(`الطالب ${student?.full_name||''} وصل إلى نهاية مسار الحفظ`);return buildReverseHifzRange(point.surah,point.ayah,requested)}
async function previewSmartPlanEstimate(){let box=$('#spEstimate');if(!box)return;try{let weekdays=selectedSmartPlanWeekdays(),basePlan={start_date:$('#spStartDate').value,end_date:$('#spEndDate').value,schedule_weekdays:weekdays,catch_up_weekday:$('#spCatchUp').value===''?null:+$('#spCatchUp').value,max_daily_multiplier:+$('#spDailyCap').value},days=smartPlansEngine.planDates(smartPlansEngine.normalizePlan({...basePlan,target_pages:1,target_units:1})).length;if(!days)throw new Error('لا توجد أيام دوام فعلية بين التاريخين');if($('#spType').value==='hifz'){
    if(!smartPlanQuranLayout())await ensureQuranLayout(true);let requested=normalizeSmartPlanRequestedPages($('#spHifzTargetPages').value);if(!requested)throw new Error('اكتب عدد الصفحات المطلوب');let scope=$('#spScope').value,members=smartPlanScopeStudentsFromForm();if(scope!=='student'&&!members.length){box.innerHTML=`<b>${fmt(requested)} صفحة لكل طالب</b> · ${days} يوم دوام<br>أضف طلاباً إلى هذا النطاق ليحسب التطبيق بداية ونهاية كل طالب.`;return}let samples=(scope==='student'?members.slice(0,1):members.slice(0,3)).map(student=>({student,range:smartPlanHifzRangeFromFormForStudent(student)}));let first=samples[0]?.range,avg=requested/days,cap=Math.max(1,Math.ceil(avg*(+$('#spDailyCap').value||1.5)));let sampleHtml=samples.map(x=>`<span><b>${esc(x.student.full_name)}:</b> ${smartPlanHifzPointText({surah:x.range.range_start_surah,ayah:x.range.range_start_ayah})} ← ${smartPlanHifzPointText({surah:x.range.range_end_surah,ayah:x.range.range_end_ayah})} · فعلي ${fmt(x.range.target_pages)} ص ≈ ${fmt(Math.ceil(x.range.target_pages-1e-9))} صفحة</span>`).join('<br>');box.innerHTML=`<b>الهدف المدخل: ${fmt(requested)} صفحة${scope==='student'?'':' لكل طالب'}</b> · ${days} يوم دوام<br>التوزيع: <b>${smartPlanDistributionText(requested,days)}</b> · المتوسط <b>${fmt(avg)} صفحة/يوم</b> · سقف التعويض <b>${fmt(cap)} صفحة/يوم</b><br>${sampleHtml}${members.length>3?`<br><span class="muted">+ ${members.length-3} طلاب تُحسب بداياتهم ونهاياتهم بشكل مستقل.</span>`:''}${first?.routeEnded?'<br><span class="muted">تنبيه: المسار وصل إلى نهاية سورة البقرة قبل استكمال الهدف المطلوب.</span>':''}`;return
  }let range=smartPlanRangeFromForm(),plan=smartPlansEngine.normalizePlan({...range,...basePlan}),daily=range.target_pages/Math.max(1,days),cap=Math.max(1,Math.ceil(daily*plan.max_daily_multiplier));box.innerHTML=`<b>${fmt(range.target_pages)} صفحة فعلية في الخطة</b> · ${days} يوم دوام<br>التوزيع: <b>${smartPlanDistributionText(range.target_pages,days)}</b> · المتوسط <b>${fmt(daily)} صفحة/يوم</b> · سقف اليوم عند التعويض <b>${fmt(cap)} صفحة</b><br><span>${smartPlanRangeText(range.range_start_page,range.range_end_page)}</span>`}catch(e){box.textContent='تحقق من نطاق القرآن والتواريخ: '+(e?.message||e)}}
function smartPlanRangeValues(plan){if(plan.goal_unit==='juz'&&plan.selected_juz?.length)return {start:Math.min(...plan.selected_juz),end:Math.max(...plan.selected_juz)};if(plan.goal_unit==='rub'&&plan.selected_rubs?.length)return {start:Math.min(...plan.selected_rubs),end:Math.max(...plan.selected_rubs)};if(plan.goal_unit==='surah'&&plan.selected_surahs?.length)return {start:Math.min(...plan.selected_surahs),end:Math.max(...plan.selected_surahs)};return {start:plan.range_start_page||1,end:plan.range_end_page||1}}
async function openPlan(studentId='',planId='',parentPlanId=''){
  if(!roleCanManage())return toast('إدارة الخطط للمحفّظ والمشرف ومسؤول النظام');let plan=planId?state.smartPlans.find(x=>x.id===planId):null,parent=parentPlanId?state.smartPlans.find(x=>x.id===parentPlanId):null,source=plan||parent||{};$('#smartPlanForm').reset();$('#spId').value=plan?.id||'';$('#spParentId').value=parent?.id||plan?.parent_plan_id||'';$('#spDialogTitle').textContent=plan?'تعديل الخطة الذكية':parent?'تخصيص الخطة لطالب':'خطة ذكية جديدة';$('#spScope').value=parent?'student':plan?.scope_type||'student';$('#spHalaqa').innerHTML=state.halaqas.map(h=>`<option value="${h.id}">${esc(h.name)}</option>`).join('');$('#spHalaqa').value=source.halaqa_id||state.students.find(x=>x.id===studentId)?.halaqa_id||state.halaqas[0]?.id||'';updateSmartPlanStudents();updateSmartPlanCategories();if(plan?.category_id)$('#spCategory').value=plan.category_id;$('#spStudent').value=studentId||plan?.student_id||'';$('#spType').value=source.plan_type||'hifz';$('#spTitle').value=parent?`${parent.title} — تخصيص`:plan?.title||'';$('#spGoalUnit').value=source.goal_unit||'pages';$('#spStartDate').value=source.start_date||today();$('#spEndDate').value=source.end_date||smartPlansEngine.addDays(today(),30);$('#spCatchUp').value=source.catch_up_weekday??'';$('#spReviewTier').value=source.review_tier&&source.review_tier!=='none'?source.review_tier:'both';$('#spNearPages').value=source.near_revision_pages??7;$('#spFarPages').value=source.far_revision_pages??20;$('#spMinEvaluation').value=source.minimum_evaluation||'very_good';$('#spDailyCap').value=String(source.max_daily_multiplier||1.5);$('#spMilestone').value=source.milestone_mode||'juz';$('#spDelayDays').value=source.delay_alert_days||3;$('#spQualityGate').checked=source.quality_gate_enabled!==false;$('#spAutoExtend').checked=source.auto_extend!==false;$('#spMilestoneApproval').checked=source.milestone_requires_approval!==false;$('#spHomePush').checked=source.home_prep_push!==false;$('#spNote').value=source.note||'';let selected=new Set(source.schedule_weekdays||[0,1,2,3,4]);$$('input[name="spWeekday"]').forEach(x=>x.checked=selected.has(+x.value));$('#spStartSurah').innerHTML=smartPlanOptions(114,x=>`${x}. ${surahs[x-1]}`);$('#spEndSurah').innerHTML=$('#spStartSurah').innerHTML;$('#spStartSurah').value=source.range_start_surah||1;$('#spEndSurah').value=source.range_end_surah||1;$('#spStartAyah').value=source.range_start_ayah||1;$('#spEndAyah').value=source.range_end_ayah||7;$('#spHifzStartSurah').innerHTML=smartPlanReverseSurahOptions();$('#spHifzTargetPages').value=source.settings?.requested_target_pages??source.target_units??source.target_pages??20;let editingHifz=plan?.plan_type==='hifz'&&Number(plan.range_start_surah);$('#spHifzStartMode').value=editingHifz?'manual':source.settings?.auto_start===false?'manual':'auto';$('#spHifzStartSurah').value=String(editingHifz?plan.range_start_surah:114);$('#spHifzStartAyah').value=String(editingHifz?plan.range_start_ayah:1);updateSmartPlanRangeFields(smartPlanRangeValues(source));updateSmartPlanScope();updateSmartPlanTypeFields();updateSmartPlanAyahLimits('start');updateSmartPlanAyahLimits('end');updateSmartPlanHifzAyahLimit();if(source.plan_type==='hifz'||!source.plan_type)await ensureQuranLayout(true);refreshSmartPlanSuggestedStart();smartPlanDlg.showModal()
}
function openSmartPlanOverride(parentId){openPlan('','',parentId)}
$('#smartPlanForm')?.addEventListener('change',event=>{if(event.target?.name==='spWeekday')previewSmartPlanEstimate()});
$('#smartPlanForm')?.addEventListener('submit',async event=>{
  event.preventDefault();let scope=$('#spScope').value,halaqaId=$('#spHalaqa').value,studentId=scope==='student'?$('#spStudent').value:null,categoryId=scope==='category'?$('#spCategory').value:null,weekdays=selectedSmartPlanWeekdays();if(!halaqaId||scope==='student'&&!studentId||scope==='category'&&!categoryId)return toast('اختر الحلقة والنطاق المطلوب');if(!weekdays.length)return toast('اختر يوم دوام واحداً على الأقل');if($('#spEndDate').value<$('#spStartDate').value)return toast('تاريخ النهاية يجب أن يكون بعد البداية');
  try{let id=$('#spId').value||offlineUuid(),old=state.smartPlans.find(x=>x.id===id),type=$('#spType').value,settings={...(old?.settings||{}),algorithm_version:'2.17.1',event_driven:true,deficit_damping:true},range;
    if(type==='hifz'){
      if(!smartPlanQuranLayout())await ensureQuranLayout(false);if(!smartPlanQuranLayout())throw new Error('بيانات مصحف المدينة الدقيقة غير جاهزة');let requested=normalizeSmartPlanRequestedPages($('#spHifzTargetPages').value,{writeBack:true});if(!requested)throw new Error('اكتب عدد الصفحات المطلوب');let members=smartPlanScopeStudentsFromForm();if(!members.length)throw new Error('لا يوجد طلاب في نطاق الخطة');settings.requested_target_pages=requested;settings.auto_start=$('#spHifzStartMode').value==='auto';settings.memorization_direction='reverse_surahs_forward_ayahs';settings.line_model=15;
      if(scope==='student'){range=smartPlanHifzRangeFromFormForStudent(members[0]);settings.memorization_start_source=settings.auto_start?'last_successful_recitation':'manual'}else{let studentRanges={};for(let student of members){let r=smartPlanHifzRangeFromFormForStudent(student);studentRanges[student.id]={target_units:requested,target_pages:r.target_pages,range_start_page:r.range_start_page,range_end_page:r.range_end_page,range_start_surah:r.range_start_surah,range_start_ayah:r.range_start_ayah,range_end_surah:r.range_end_surah,range_end_ayah:r.range_end_ayah,settings:{requested_target_pages:requested}}}settings.student_ranges=studentRanges;if(!settings.auto_start)settings.group_manual_start={surah:+$('#spHifzStartSurah').value,ayah:+$('#spHifzStartAyah').value};else delete settings.group_manual_start;range={goal_unit:'pages',target_units:requested,target_pages:requested,range_start_page:null,range_end_page:null,range_start_surah:null,range_start_ayah:null,range_end_surah:null,range_end_ayah:null,selected_surahs:[],selected_juz:[],selected_rubs:[]}}
    }else range=smartPlanRangeFromForm();
    let requestedLabel=type==='hifz'?Number(settings.requested_target_pages):range.target_pages,plan={...range,id,scope_type:scope,halaqa_id:halaqaId,student_id:studentId,category_id:categoryId,parent_plan_id:$('#spParentId').value||null,plan_type:type,review_tier:type==='review'?$('#spReviewTier').value:'none',title:$('#spTitle').value.trim()||`${smartPlanTypeAr[type]} ${type==='hifz'?`${fmt(requestedLabel)} صفحة`:smartPlanRangeText(range.range_start_page,range.range_end_page)}`,start_date:$('#spStartDate').value,end_date:$('#spEndDate').value,schedule_weekdays:weekdays,catch_up_weekday:$('#spCatchUp').value===''?null:+$('#spCatchUp').value,max_daily_multiplier:+$('#spDailyCap').value,auto_extend:$('#spAutoExtend').checked,quality_gate_enabled:$('#spQualityGate').checked,minimum_evaluation:$('#spMinEvaluation').value,near_revision_pages:+$('#spNearPages').value||0,far_revision_pages:+$('#spFarPages').value||0,milestone_mode:$('#spMilestone').value,milestone_requires_approval:$('#spMilestoneApproval').checked,delay_alert_days:+$('#spDelayDays').value||3,home_prep_push:$('#spHomePush').checked,status:old?.status||'active',note:$('#spNote').value.trim()||null,settings,revision:old?.revision||1,created_by:old?.created_by||state.user.id,created_at:old?.created_at||new Date().toISOString(),updated_at:new Date().toISOString()};saveSmartPlanLocal(plan);smartPlanDlg.close();render()}catch(e){toast('تعذر إنشاء الخطة: '+(e?.message||e))}
});

function archiveSmartPlan(id){if(!roleCanManage())return;let plan=state.smartPlans.find(x=>x.id===id);if(!plan)return;if(!confirm(`أرشفة خطة «${plan.title}»؟\nلن تُحذف سجلات التسميع أو أحداث الخطة.`))return;saveSmartPlanLocal({...plan,status:'archived',updated_at:new Date().toISOString()});render()}
function approveSmartPlanMilestone(planId,studentId,key){let plan=state.smartPlans.find(x=>x.id===planId);if(!plan||!roleCanManage())return;recordSmartPlanEvent(planId,studentId,'milestone_approved',{milestone_key:key,approved_at:new Date().toISOString()});toast('تم اعتماد الاختبار وفتح المقرر التالي');render();if(state.sessionView)setTimeout(()=>injectSmartPlanSessionWidgets(state.sessionView),0)}

function smartPlanForSession(student,date,sessionType='tasmee'){
  let plans=effectiveSmartPlans(student,date),wanted=sessionType==='review'?'review':sessionType==='sard'?'sard':sessionType==='test'?'hifz':'hifz',plan=plans.find(x=>x.plan_type===wanted)||plans[0];if(!plan)return null;let progress=smartPlanProgress(plan,student.id,date);return {plan,progress,review:plan.plan_type==='review'?smartPlanReviewSuggestions(student,date,plan):null}
}
function smartPlanDailyAchieved(plan,studentId,date){return Number(smartPlanProgress(plan,studentId,date).completedToday||0)}
function smartPlanSessionWidget(student,session){let item=smartPlanForSession(student,session.session_date,session.session_type);if(!item)return '';let {plan,progress,review}=item,a=progress.assignment,done=smartPlanDailyAchieved(plan,student.id,session.session_date),required=review?(review.nearRanges.reduce((s,x)=>s+x.end-x.start+1,0)+review.farRanges.reduce((s,x)=>s+x.end-x.start+1,0)):Number((progress.dailyTarget??a.pages)||0),remaining=Math.max(0,required-done),extra=Math.max(0,done-required);return `<div class="smart-session-plan ${progress.health}"><div><b>المقرر الذكي اليوم</b><span>${smartPlanAssignmentLabel(a)}</span>${review?`<small>قريب: ${smartPlanRangesText(review.nearRanges)}${review.farDue?` · بعيد: ${smartPlanRangesText(review.farRanges)}`:''}</small>`:''}</div><div class="smart-session-kpis"><span>مطلوب <b>${fmt(required)}</b></span><span>أنجز <b>${fmt(done)}</b></span><span>متبقي <b>${fmt(remaining)}</b></span>${extra?`<span>متقدم <b>+${fmt(extra)}</b></span>`:''}</div><button class="mini" type="button" onclick="oneTapSmartPlanPrefill('${student.id}','${session.id}','${plan.id}')">تسميع المقرر اليومي</button>${a.milestone?`<button class="mini" type="button" onclick="approveSmartPlanMilestone('${plan.id}','${student.id}','${a.milestone.key}')">اعتماد ${esc(a.milestone.label)}</button>`:''}</div>`}
function injectSmartPlanSessionWidgets(sessionId){let session=state.sessions.find(x=>String(x.id)===String(sessionId));if(!session)return;for(let student of activeStudents().filter(x=>x.halaqa_id===session.halaqa_id)){let card=$(`#roster_${student.id}`);if(!card)continue;card.querySelector('.smart-session-plan')?.remove();let html=smartPlanSessionWidget(student,session);if(html)card.querySelector('.roster-recitations')?.insertAdjacentHTML('beforebegin',html)}}
const smartPlanBaseSessionRosterPage=sessionRosterPage;
sessionRosterPage=function(id){let html=smartPlanBaseSessionRosterPage(id);setTimeout(()=>injectSmartPlanSessionWidgets(id),0);return html};

function addSmartPlanPageRow(plan,kind,start,end,date){if(!start||!end)return null;addRecitationRow(kind);let row=$$('#recitationRows .rec-row').at(-1),id=row.dataset.id,modeButton=row.querySelectorAll('.seg button')[1];setRecMode(modeButton,'pages');$('#'+id+'PF').value=start;$('#'+id+'PT').value=end;row.dataset.startPage=start;row.dataset.endPage=end;row.dataset.pages=end-start+1;row.dataset.smartPlanId=plan.id;row.dataset.smartPlanType=plan.plan_type;row.dataset.smartPlanDate=date;row.querySelector('.rType').value=kind;calcRecRow(row);return row}
async function addSmartPlanAyahRow(plan,kind,segment,date){if(!segment?.surah||!segment?.startAyah||!segment?.endAyah)return null;addRecitationRow(kind);let row=$$('#recitationRows .rec-row').at(-1),id=row.dataset.id,modeButton=row.querySelectorAll('.seg button')[0];setRecMode(modeButton,'ayahs');$('#'+id+'SS').value=segment.surah;$('#'+id+'SA').value=segment.startAyah;$('#'+id+'ES').value=segment.surah;$('#'+id+'EA').value=segment.endAyah;row.dataset.smartPlanId=plan.id;row.dataset.smartPlanType=plan.plan_type;row.dataset.smartPlanDate=date;row.querySelector('.rType').value=kind;await calcRecRow(row);return row}
async function oneTapSmartPlanPrefill(studentId,sessionId,planId){let session=state.sessions.find(x=>String(x.id)===String(sessionId)),student=state.students.find(x=>x.id===studentId),rawPlan=state.smartPlans.find(x=>x.id===planId);if(!session||!student||!rawPlan)return toast('تعذر العثور على مقرر الخطة');let plan=materializeSmartPlan(rawPlan,student);if(!reportDlg.open)await openDailyForStudent(studentId,sessionId);let empty=$$('.rec-row').filter(r=>!r.dataset.dbId&&Number(r.dataset.pages||0)===0);empty.forEach(r=>r.remove());let progress=smartPlanProgress(rawPlan,studentId,session.session_date),a=progress.assignment,added=0;if(plan.plan_type==='review'){let review=smartPlanReviewSuggestions(student,session.session_date,plan);for(let range of review.nearRanges){addSmartPlanPageRow(plan,'review_near',range.start,range.end,session.session_date);added++}for(let range of review.farRanges){addSmartPlanPageRow(plan,'review_far',range.start,range.end,session.session_date);added++}}else if(plan.plan_type==='hifz'&&a.ayahSegments?.length&&!a.milestone){let kind=a.kind==='hifz'?'new_hifz':'review_far';for(let segment of a.ayahSegments){await addSmartPlanAyahRow(plan,kind,segment,session.session_date);added++}}else{let kind=a.kind==='hifz'?'new_hifz':a.kind==='sard'?'sard':a.kind==='test'?'test':'review_far';if(a.retryRanges?.length){for(let range of a.retryRanges){addSmartPlanPageRow(plan,kind,range.start,range.end,session.session_date);added++}}else if(a.startPage&&a.endPage){addSmartPlanPageRow(plan,kind,a.startPage,a.endPage,session.session_date);added++}}if(!added){addRecitationRow(plan.plan_type==='sard'?'sard':plan.plan_type==='review'?'review_near':'new_hifz');toast('لا يوجد مقدار تلقائي اليوم؛ أضيف بند فارغ للتسجيل اليدوي')}else toast('تمت تعبئة المقرر اليومي من الخطة بالآيات المحددة')}

function injectSmartPlanReportStrip(studentId,sessionId){let student=state.students.find(x=>x.id===studentId),session=state.sessions.find(x=>String(x.id)===String(sessionId));if(!student||!session)return;$('#smartPlanReportStrip')?.remove();let item=smartPlanForSession(student,session.session_date,session.session_type);if(!item)return;let holder=document.createElement('div');holder.id='smartPlanReportStrip';holder.innerHTML=smartPlanSessionWidget(student,session);let anchor=$('#reportDlg .section-head');anchor?.insertAdjacentElement('beforebegin',holder)}
const smartPlanBaseOpenDailyForStudent=openDailyForStudent;
openDailyForStudent=async function(studentId,sessionId=null){await smartPlanBaseOpenDailyForStudent(studentId,sessionId);let actual=sessionId||$('#rpSession')?.value;injectSmartPlanReportStrip(studentId,actual)};

const smartPlanBaseStudentProfile=studentProfile;
studentProfile=function(id){smartPlanBaseStudentProfile(id);let student=state.students.find(x=>x.id===id),content=$('#content');if(!student||!content)return;let panel=document.createElement('div');panel.innerHTML=smartPlanStudentPanel(student,today(),false);let back=content.querySelector('button.btn.btn-ghost:last-child');if(back)back.insertAdjacentElement('beforebegin',panel);else content.appendChild(panel)};

async function checkSmartPlanAlerts(){
  if(!roleCanManage()||!state.smartPlansAvailable||!navigator.onLine||typeof invokeNotify!=='function')return;let date=today(),tomorrow=smartPlansEngine.addDays(date,1),evening=new Date().getHours()>=17;
  for(let student of activeStudents()){
    for(let plan of effectiveSmartPlans(student,date)){let progress=smartPlanProgress(plan,student.id,date);if(progress.consecutiveMissed>=plan.delay_alert_days){await invokeNotify({action:'event_student',kind:'system',student_id:student.id,source_key:`smart-plan-delay:${plan.id}:${student.id}:${date}`,title:`تنبيه الخطة · ${student.full_name}`,body:`الخطة متأخرة ${progress.consecutiveMissed} أيام دوام. المتبقي ${fmt(progress.remaining)} صفحة، والحالة ${progress.healthLabel}.`,deep_link:`student:${student.id}`,data:{smart_plan_id:plan.id,health:progress.health,missed_days:progress.consecutiveMissed}},{silent:true})}}
    if(evening){let next=smartPlanForSession(student,tomorrow,'tasmee');if(next?.plan?.home_prep_push&&next.progress.assignment.startPage){let a=next.progress.assignment;await invokeNotify({action:'event_student',kind:'system',student_id:student.id,source_key:`smart-plan-prep:${next.plan.id}:${student.id}:${tomorrow}`,title:`تحضير الغد · ${student.full_name}`,body:`مطلوب غداً ${smartPlanAssignmentLabel(a)}.`,deep_link:`student:${student.id}`,data:{smart_plan_id:next.plan.id,plan_date:tomorrow,start_page:a.startPage,end_page:a.endPage}},{silent:true})}}
  }
}
