/* Halaqati v2.40.3 — Chromium/WebView Vector PDF engine */
(function(){
  'use strict';
  const VERSION='2.40.6-vector-pdf-zero-byte-session-safe';
  const FONT_CACHE=new Map();
  let styleCachePromise=null;

  function notify(msg){
    try{ if(typeof toast==='function') return toast(msg); }catch(_e){}
    console.log('[Halaqati PDF]',msg);
  }
  function escAttr(s){return String(s??'').replace(/&/g,'&amp;').replace(/"/g,'&quot;').replace(/</g,'&lt;').replace(/>/g,'&gt;')}
  function latinDigits(s){return String(s??'').replace(/[٠-٩]/g,d=>'0123456789'['٠١٢٣٤٥٦٧٨٩'.indexOf(d)]).replace(/[۰-۹]/g,d=>'0123456789'['۰۱۲۳۴۵۶۷۸۹'.indexOf(d)])}
  function safeFilename(name){
    let s=latinDigits(name||'halaqati-report.pdf').replace(/[\\/:*?"<>|\r\n]+/g,'_').replace(/\s+/g,' ').trim();
    if(!/\.pdf$/i.test(s))s+='.pdf';
    return s.slice(0,120)||'halaqati-report.pdf';
  }
  function isNative(){return !!(window.Capacitor?.isNativePlatform?.()||window.Capacitor?.getPlatform?.()==='android'||window.Capacitor?.getPlatform?.()==='ios')}
  function progress(text){
    let el=document.getElementById('hfVectorPdfProgress');
    if(!el){
      el=document.createElement('div');el.id='hfVectorPdfProgress';el.dir='rtl';
      el.style.cssText='position:fixed;inset:0;z-index:2147483640;background:rgba(247,247,242,.97);display:grid;place-items:center;font-family:Cairo,Tahoma,Arial,sans-serif;color:#0d3b2f';
      el.innerHTML='<div style="background:#fff;border:1px solid #dfe6e2;border-radius:18px;padding:20px 24px;box-shadow:0 16px 50px #0d3b2f22;text-align:center;min-width:240px"><b style="display:block;font-size:17px;margin-bottom:5px">جاري إنشاء ملف PDF</b><span style="font-size:12px;color:#68736e"></span></div>';
      document.body.appendChild(el);
    }
    const span=el.querySelector('span');if(span)span.textContent=text||'PDF متجهي · Cairo · RTL';
    return el;
  }
  function hideProgress(){document.getElementById('hfVectorPdfProgress')?.remove()}
  function toDataUrl(blob){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result||''));r.onerror=()=>reject(r.error||new Error('FileReader failed'));r.readAsDataURL(blob)})}
  async function inlineUrl(raw,base){
    const clean=String(raw||'').trim().replace(/^['"]|['"]$/g,'');
    if(!clean||clean.startsWith('data:')||clean.startsWith('#'))return clean;
    let abs;try{abs=new URL(clean,base||location.href).href}catch(_e){return clean}
    if(FONT_CACHE.has(abs))return FONT_CACHE.get(abs);
    try{
      const r=await fetch(abs,{cache:'force-cache'});if(!r.ok)throw new Error(String(r.status));
      const blob=await r.blob(),data=await toDataUrl(blob);FONT_CACHE.set(abs,data);return data;
    }catch(_e){return abs}
  }
  async function inlineCssUrls(css,base){
    const matches=[...String(css||'').matchAll(/url\(([^)]+)\)/g)];
    if(!matches.length)return css;
    let out=css;
    for(const m of matches){
      const raw=m[1],clean=raw.trim().replace(/^['"]|['"]$/g,'');
      // Inline local/web fonts and small style assets. This keeps the dedicated Android WebView independent of Capacitor's asset server.
      if(!/\.(woff2?|ttf|otf|svg|png|jpe?g)(\?|#|$)/i.test(clean)&&!clean.includes('/fonts/'))continue;
      const data=await inlineUrl(clean,base);
      if(data&&data!==clean)out=out.split(m[0]).join(`url("${data}")`);
    }
    return out;
  }
  async function collectDocumentCss(){
    if(styleCachePromise)return styleCachePromise;
    styleCachePromise=(async()=>{
      const chunks=[];
      for(const node of [...document.querySelectorAll('link[rel="stylesheet"],style')]){
        if(node.tagName==='STYLE'){chunks.push(node.textContent||'');continue}
        const href=node.href;if(!href)continue;
        try{const r=await fetch(href,{cache:'force-cache'});if(!r.ok)continue;chunks.push(await inlineCssUrls(await r.text(),href))}catch(_e){}
      }
      return chunks.join('\n');
    })();
    return styleCachePromise;
  }
  function sanitizeClone(root){
    root.querySelectorAll('script,iframe,object,embed,form,video,audio').forEach(n=>n.remove());
    root.querySelectorAll('*').forEach(el=>{
      for(const a of [...el.attributes]){
        const n=a.name.toLowerCase(),v=String(a.value||'');
        if(n.startsWith('on'))el.removeAttribute(a.name);
        if((n==='href'||n==='src'||n==='xlink:href')&&/^\s*javascript:/i.test(v))el.removeAttribute(a.name);
      }
      el.removeAttribute('contenteditable');el.removeAttribute('spellcheck');
    });
    return root;
  }
  async function inlineImages(root){
    const imgs=[...root.querySelectorAll('img[src]')];
    await Promise.all(imgs.map(async img=>{
      const src=img.getAttribute('src');if(!src||src.startsWith('data:'))return;
      try{const abs=new URL(src,location.href).href;const r=await fetch(abs,{cache:'force-cache'});if(!r.ok)return;img.src=await toDataUrl(await r.blob())}catch(_e){}
    }));
  }
  function printOverrides(orientation,fontFamily){
    const size=orientation==='portrait'?'A4 portrait':'A4 landscape';
    return `
      @page{size:${size};margin:7mm}
      html,body{margin:0!important;padding:0!important;background:#fff!important;direction:rtl!important;-webkit-print-color-adjust:exact!important;print-color-adjust:exact!important}
      body{font-family:${fontFamily||"'Cairo',Tahoma,Arial,sans-serif"}!important;color:#18231f}
      /* The legacy app stylesheet intentionally hides body descendants during print and
         only re-shows #reportExportArea. The vector exporter prints a standalone clone
         named #hf-vector-print-root, so that old rule made Chromium emit white pages.
         These later !important rules are deliberately ID-scoped and restore only the
         standalone report tree without exposing any application UI. */
      @media print{
        html,body{visibility:visible!important}
        #hf-vector-print-root,#hf-vector-print-root *{visibility:visible!important}
        #hf-vector-print-root{display:block!important;position:static!important}
      }
      #hf-vector-print-root{width:100%!important;max-width:none!important;margin:0!important;padding:0!important;direction:rtl!important;background:#fff!important}
      .pro-report{width:100%!important;max-width:none!important;margin:0!important;padding:0!important}
      .pro-report-page{width:100%!important;max-width:none!important;min-height:0!important;margin:0!important;padding:0!important;box-shadow:none!important;border:0!important;border-radius:0!important;overflow:visible!important;break-after:page!important;page-break-after:always!important;background:#fff!important}
      .pro-report-page:last-child{break-after:auto!important;page-break-after:auto!important}
      .pro-table-wrap{width:100%!important;max-width:100%!important;overflow:visible!important}
      table.pro-table{width:100%!important;max-width:100%!important;table-layout:fixed!important;border-collapse:collapse!important}
      table.pro-table thead{display:table-header-group!important}
      table.pro-table tfoot{display:table-footer-group!important}
      table.pro-table tr{break-inside:avoid!important;page-break-inside:avoid!important}
      table.pro-table th,table.pro-table td{box-sizing:border-box!important;overflow:visible!important;text-overflow:clip!important}
      table.pro-table .name,table.pro-table .hf-col-name{white-space:nowrap!important;word-break:keep-all!important;overflow-wrap:normal!important}
      table.pro-table .hf-col-compact{white-space:nowrap!important;word-break:keep-all!important}
      table.pro-table .hf-col-flex,table.pro-table .text-cell,table.pro-table .hf-col-auto{white-space:normal!important;overflow-wrap:anywhere!important;word-break:normal!important}
      .student-report-card,.pro-head,.pro-meta,.pro-kpis,.pro-footer{break-inside:avoid!important;page-break-inside:avoid!important}
      .hf-edit-note,.hf-pdf-progress,.hf-pdf-render-stage,#reportPreviewDlg{display:none!important}
    `;
  }
  async function buildVectorHtml(source,orientation){
    if(!source)throw new Error('لا يوجد محتوى PDF');
    try{window.applyAutoFitPdfTables?.(source)}catch(_e){}
    const clone=sanitizeClone(source.cloneNode(true));
    clone.id='hf-vector-print-root';clone.style.transform='none';clone.style.boxShadow='none';clone.style.width='100%';clone.style.maxWidth='none';
    clone.querySelectorAll('[data-hf-base-font]').forEach(el=>el.removeAttribute('data-hf-base-font'));
    await inlineImages(clone);
    const css=await collectDocumentCss();
    const fontFamily=source.style.fontFamily||"'Cairo',Tahoma,Arial,sans-serif";
    return '<!doctype html><html lang="ar" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><style>'+css+'\n'+printOverrides(orientation,fontFamily)+'</style></head><body>'+clone.outerHTML+'<script>document.documentElement.dataset.hfReady="1";<\/script></body></html>';
  }
  function persistPrintRecoveryState(){
    // Android may move the app to the background while the system print UI is open.
    // Save the verified offline identity + current page before handing control to the spooler.
    try{ if(typeof saveOfflineAuth==='function'&&typeof state!=='undefined'&&state?.user) saveOfflineAuth(state.user); }catch(_e){}
    try{ if(typeof cacheSnapshot==='function') cacheSnapshot(); }catch(_e){}
    try{
      const page=(typeof state!=='undefined'&&state?.page)||'reports';
      localStorage.setItem('halaqati_print_resume_v2406',JSON.stringify({page,at:Date.now()}));
    }catch(_e){}
  }
  function removeLivePrintSurface(){
    document.getElementById('hfVectorLivePrintStyle')?.remove();
    document.getElementById('hf-vector-print-root')?.remove();
  }
  async function prepareLivePrintSurface(source,orientation){
    if(!source)throw new Error('لا يوجد محتوى PDF');
    removeLivePrintSurface();
    try{window.applyAutoFitPdfTables?.(source)}catch(_e){}
    const clone=sanitizeClone(source.cloneNode(true));
    clone.id='hf-vector-print-root';
    clone.setAttribute('aria-hidden','true');
    try{clone.inert=true}catch(_e){}
    clone.style.transform='none';clone.style.boxShadow='none';clone.style.width='100%';clone.style.maxWidth='none';
    clone.querySelectorAll('[data-hf-base-font]').forEach(el=>el.removeAttribute('data-hf-base-font'));
    await inlineImages(clone);
    const fontFamily=source.style.fontFamily||"'Cairo',Tahoma,Arial,sans-serif";
    const style=document.createElement('style');
    style.id='hfVectorLivePrintStyle';
    style.textContent=printOverrides(orientation,fontFamily)+`

      /* v2.40.6: keep the staged print tree fully laid out but completely off-screen
         in normal app mode. Print media moves exactly this tree back onto the page. */
      @media screen{
        #hf-vector-print-root{position:fixed!important;left:-200vw!important;right:auto!important;top:0!important;width:${orientation==='portrait'?'210mm':'297mm'}!important;max-width:none!important;visibility:hidden!important;pointer-events:none!important;z-index:-2147480000!important}
        #hf-vector-print-root *{visibility:hidden!important;pointer-events:none!important}
      }
      @media print{
        #reportExportArea{display:none!important;visibility:hidden!important}
        #hf-vector-print-root{left:auto!important;right:auto!important;top:auto!important;visibility:visible!important;pointer-events:auto!important;z-index:auto!important}
        #hf-vector-print-root *{visibility:visible!important}
      }
    `;
    document.head.appendChild(style);
    document.body.appendChild(clone);
    try{ if(document.fonts?.ready) await document.fonts.ready; }catch(_e){}
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    // Force one synchronous layout read before PrintManager creates its adapter.
    try{void clone.getBoundingClientRect().width}catch(_e){}
    return clone;
  }
  async function nativeExportCurrent(source,filename,orientation){
    const p=window.Capacitor?.Plugins?.HalaqatiPdf;
    if(!p?.exportPdf)throw new Error('محرك PDF المتجهي غير متاح في هذه النسخة');
    persistPrintRecoveryState();
    await prepareLivePrintSurface(source,orientation);
    try{
      // The native call deliberately stays pending until Android's PrintJob reaches a
      // terminal state. Do not remove the print tree while the spooler is still writing.
      return await p.exportPdf({filename,orientation,useCurrentWebView:true});
    }finally{
      removeLivePrintSurface();
    }
  }
  async function nativeExportHtml(html,filename,orientation){
    const p=window.Capacitor?.Plugins?.HalaqatiPdf;
    if(!p?.exportPdf)throw new Error('محرك PDF المتجهي غير متاح في هذه النسخة');
    return await p.exportPdf({html,filename,orientation,useCurrentWebView:false});
  }
  async function webPrint(html){
    return await new Promise((resolve,reject)=>{
      const frame=document.createElement('iframe');frame.setAttribute('aria-hidden','true');frame.style.cssText='position:fixed;left:-10000px;top:0;width:1px;height:1px;border:0;opacity:0;pointer-events:none';
      let done=false,timer;
      const finish=ok=>{if(done)return;done=true;clearTimeout(timer);setTimeout(()=>frame.remove(),500);ok?resolve():reject(new Error('تعذر فتح نافذة طباعة PDF'))};
      frame.onload=()=>{
        try{
          const w=frame.contentWindow,d=w.document;
          const start=()=>{try{w.focus();w.print();setTimeout(()=>finish(true),500)}catch(e){finish(false)}};
          if(d.fonts?.ready)d.fonts.ready.then(start).catch(start);else start();
        }catch(_e){finish(false)}
      };
      document.body.appendChild(frame);frame.srcdoc=html;timer=setTimeout(()=>finish(false),15000);
    });
  }
  async function exportElementVectorPdf(source,filename,orientation='landscape'){
    const overlay=progress(isNative()?'تجهيز التقرير داخل صفحة التطبيق…':'تجهيز HTML/CSS والخطوط…');
    try{
      if(isNative()){
        overlay.querySelector('span').textContent='تجهيز الطباعة المتجهية ثم انتظار اكتمال الحفظ…';
        const res=await nativeExportCurrent(source,safeFilename(filename),orientation);
        if(res?.cancelled) notify('تم إلغاء الطباعة');
        else if(res?.completed) notify('اكتملت عملية حفظ/طباعة PDF');
        else if(res?.timedOut) notify('ما زالت مهمة الطباعة لدى النظام؛ افحص التنزيلات قبل إعادة المحاولة');
        return res;
      }
      const html=await buildVectorHtml(source,orientation);
      overlay.querySelector('span').textContent='فتح نافذة Chromium للحفظ كـ PDF…';
      await webPrint(html);notify('اختر «حفظ بتنسيق PDF» من نافذة الطباعة');return {saved:false,printDialog:true};
    }finally{hideProgress()}
  }

  window.downloadReportPdfFromPreview=async function(){
    try{
      const paper=document.getElementById('reportPreviewPaper');
      if(!paper||!paper.innerHTML.trim())throw new Error('افتح معاينة التقرير أولاً');
      const orientation=document.getElementById('hfOrientation')?.value||paper.dataset.orientation||'landscape';
      const isStudents=/بيانات الطلاب الأساسية/.test(paper.textContent||'');
      let stamp='';try{stamp=typeof reportFileStamp==='function'?reportFileStamp():''}catch(_e){}
      let date='';try{date=typeof today==='function'?today():new Date().toISOString().slice(0,10)}catch(_e){date=new Date().toISOString().slice(0,10)}
      const name=isStudents?`بيانات_طلاب_حلقتي_${date}.pdf`:`تقرير_حلقتي_${stamp||date}.pdf`;
      return await exportElementVectorPdf(paper,name,orientation);
    }catch(e){console.error('Halaqati vector PDF error',e);hideProgress();notify('تعذر إنشاء PDF: '+(e?.message||e))}
  };

  // Parent/guardian PDF uses the same vector engine; the image-sharing button remains raster by design.
  window.exportParentReportPdf=async function(id,p='month'){
    try{
      if(!document.getElementById('opsParentReportCard')&&typeof openParentReport==='function')openParentReport(id,p);
      await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
      const card=document.getElementById('opsParentReportCard');if(!card)throw new Error('تعذر تجهيز تقرير ولي الأمر');
      let date='';try{date=typeof today==='function'?today():new Date().toISOString().slice(0,10)}catch(_e){date=new Date().toISOString().slice(0,10)}
      return await exportElementVectorPdf(card,`halaqati-parent-${id}-${p}-${date}.pdf`,'portrait');
    }catch(e){console.error('Halaqati parent vector PDF error',e);hideProgress();notify('تعذر إنشاء PDF: '+(e?.message||e))}
  };

  window.HalaqatiVectorPdf={version:VERSION,buildHtml:buildVectorHtml,exportElement:exportElementVectorPdf,prepareLivePrintSurface,nativeExportHtml};
  console.info('Halaqati vector PDF engine loaded',VERSION);
})();
